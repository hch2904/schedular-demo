# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

### To run this project

* `npm i`
* `npm start`

## Available Scripts

In the project directory, you can run:
### `npm i`

This would install the dependencies.
### `npm start`

this would start a dev server and start the project. 

### `npm run build`

this would create a production build for the project that can be used for deploying to server. 